<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="60"/>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="142"/>
        <source>Access and Use Constraints</source>
        <translation>Ligipääsu ja kasutamise piirangud</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="174"/>
        <source>Credits</source>
        <translation>Krediidid</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="207"/>
        <source>About the App</source>
        <translation>Teave rakenduse kohta</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="223"/>
        <source>This app was built using the new AppStudio for ArcGIS. Mapping API provided by Esri.</source>
        <translation>See rakendus loodi uue AppStudio for ArcGIS-i abil. Kaardi API-t pakub Esri.</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="238"/>
        <source>Version</source>
        <translation>Versioon</translation>
    </message>
</context>
<context>
    <name>AddDetailsPage</name>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="117"/>
        <source>Add Details</source>
        <translation>Lisa üksikasjad</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="172"/>
        <source>Submit</source>
        <translation>Esita</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="184"/>
        <location filename="../pages/AddDetailsPage.qml" line="188"/>
        <source>Unable to submit.</source>
        <translation>Ei saa esitada.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="185"/>
        <source>Add a valid map path.</source>
        <translation>Lisage sobiv kaardi sisu teekond.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="189"/>
        <source>Add a valid map area.</source>
        <translation>Lisage sobiv kaardiala.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="156"/>
        <source>Save</source>
        <translation>Salvesta</translation>
    </message>
</context>
<context>
    <name>AddPhotoPage</name>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="244"/>
        <source>Add Photo</source>
        <translation>Lisa foto</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Add upto %1 photos.</source>
        <translation>Lisada saab kuni %1 fotot.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Larger images will be resized to %1 pixels.</source>
        <translation>Mahukamate piltide suurust muudetakse %1 pikslini.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="297"/>
        <source>Take Photo</source>
        <translation>Pildista</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="328"/>
        <location filename="../pages/AddPhotoPage.qml" line="564"/>
        <source>Select Photo</source>
        <translation>Vali foto</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="413"/>
        <source>Next</source>
        <translation>Järgmine</translation>
    </message>
</context>
<context>
    <name>AndroidPictureChooser</name>
    <message>
        <location filename="../controls/AndroidPictureChooser.qml" line="103"/>
        <source>Sorry, no photos!</source>
        <translation>Fotosid kahjuks pole.</translation>
    </message>
</context>
<context>
    <name>CameraWindow</name>
    <message>
        <location filename="../pages/CameraWindow.qml" line="46"/>
        <source>Camera</source>
        <translation>Kaamera</translation>
    </message>
</context>
<context>
    <name>ConfirmBox</name>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="34"/>
        <source>Are you sure you want to discard?</source>
        <translation>Kas soovite kindlasti loobuda?</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="132"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="143"/>
        <source>Yes</source>
        <translation>Jah</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="154"/>
        <source>No</source>
        <translation>Ei</translation>
    </message>
</context>
<context>
    <name>DisclamerPage</name>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="72"/>
        <source>Disclaimer</source>
        <translation>Keeldumine</translation>
    </message>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="141"/>
        <source>Agree</source>
        <translation>Nõustun</translation>
    </message>
</context>
<context>
    <name>EditControl</name>
    <message>
        <location filename="../controls/EditControl.qml" line="46"/>
        <source>Done</source>
        <translation>Valmis</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter some text</source>
        <translation>Sisestage tekst</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Pick a Date</source>
        <translation>Valige kuupäev</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter a number</source>
        <translation>Sisestage number</translation>
    </message>
</context>
<context>
    <name>ImageViewer</name>
    <message>
        <location filename="../controls/ImageViewer.qml" line="688"/>
        <source>NAME</source>
        <translation>NIMI</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="747"/>
        <source>LOCATION</source>
        <translation>ASUKOHT</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="755"/>
        <source>Not Set</source>
        <translation>Pole määratud</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="1052"/>
        <source>Are you sure you want to discard the changes?</source>
        <translation>Kas soovite muudatustest kindlasti loobuda?</translation>
    </message>
</context>
<context>
    <name>LandingPage</name>
    <message>
        <location filename="../pages/LandingPage.qml" line="39"/>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="221"/>
        <source>New</source>
        <translation>Uus</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="241"/>
        <source>Drafts</source>
        <translation>Mustandid</translation>
    </message>
</context>
<context>
    <name>PickTypePage</name>
    <message>
        <location filename="../pages/PickTypePage.qml" line="117"/>
        <source>Select Report Type</source>
        <translation>Aruande tüübi valimine</translation>
    </message>
    <message>
        <location filename="../pages/PickTypePage.qml" line="173"/>
        <source>Next</source>
        <translation>Järgmine</translation>
    </message>
</context>
<context>
    <name>PictureChooser</name>
    <message>
        <location filename="../controls/PictureChooser.qml" line="29"/>
        <source>Pictures</source>
        <translation>Pildid</translation>
    </message>
    <message>
        <location filename="../controls/PictureChooser.qml" line="120"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
</context>
<context>
    <name>QuickReportApp</name>
    <message>
        <location filename="../QuickReportApp.qml" line="245"/>
        <source>Submitting the report</source>
        <translation>Aruande esitamine</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="247"/>
        <source>Sorry there was an error!</source>
        <translation>Kahjuks ilmnes tõrge.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="248"/>
        <source>Photo size is </source>
        <translation>Foto suurus on </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="246"/>
        <source>Submitted successfully.</source>
        <translation>Edastatud.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="249"/>
        <source>Adding photo to draft: </source>
        <translation>Foto lisamine mustandisse: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="250"/>
        <source>Photo added successfully: </source>
        <translation>Foto on lisatud: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="251"/>
        <source>Sorry could not add photo: </source>
        <translation>Kahjuks ei saanud fotot lisada: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="253"/>
        <source>Please save as draft and submit later.</source>
        <translation>Salvestage see mustandina ja esitage hiljem.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="254"/>
        <source>Saved as draft.</source>
        <translation>Salvestatud mustandina.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="578"/>
        <location filename="../QuickReportApp.qml" line="691"/>
        <source>Unable to initialize - Invalid service.</source>
        <translation>Ei saa käivitada – sobimatu teenus.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="579"/>
        <source>Please make sure the ArcGIS feature service supports</source>
        <translation>Veenduge, et ArcGIS-i objektiteenus toetab</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="683"/>
        <source>Unable to initialize - Insufficient capability.</source>
        <translation>Ei saa käivitada – ebapiisavad võimalused.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="684"/>
        <source>Please make sure the ArcGIS feature service is editable.</source>
        <translation>Veenduge, et ArcGIS-i objektiteenus on redigeeritav.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="692"/>
        <source>Please make sure you have configured a valid ArcGIS feature service url.</source>
        <translation>Veenduge, et olete konfigureerinud ArcGIS-i sobiva objektiteenuse URL-i.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="698"/>
        <source>Unable to initialize - Network not available.</source>
        <translation>Ei saa käivitada – võrk pole saadaval.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="699"/>
        <source>Turn off airplane mode or use wifi to access data.</source>
        <translation>Andmetele juurdepääsuks lülitage lennukirežiim välja või kasutage WiFi-ühendust.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="711"/>
        <source>Sorry, something went wrong.</source>
        <translation>Kahjuks läks midagi valesti.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="967"/>
        <source>Device OS</source>
        <translation>Seadme opsüsteem</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="968"/>
        <source>Device Locale</source>
        <translation>Seadme lokaat</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="969"/>
        <source>App Version</source>
        <translation>Rakenduse versioon</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="970"/>
        <source>AppStudio Version</source>
        <translation>AppStudio versioon</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="973"/>
        <source>Feedback for</source>
        <translation>Tagasiside:</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="282"/>
        <source>Gallery</source>
        <translation>Galerii</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="252"/>
        <source>Click Done to continue.</source>
        <translation>Jätkamiseks klõpsake nuppu Valmis.</translation>
    </message>
</context>
<context>
    <name>RefineLocationPage</name>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="50"/>
        <source>Map not available in offline mode.</source>
        <translation>Kaart pole võrguühenduseta režiimis saadaval.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="51"/>
        <source>Using device GPS.</source>
        <translation>Kasutatakse seadme GPS-i.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="52"/>
        <source>Accuracy</source>
        <translation>Täpsus</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="53"/>
        <source>Latitude</source>
        <translation>Laiuskraad</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="54"/>
        <source>Longitude</source>
        <translation>Pikkuskraad</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="55"/>
        <source>Select Bookmark</source>
        <translation>Vali järjehoidja</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Location</source>
        <translation>Lisa asukoht</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Path</source>
        <translation>Lisa teekond</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Area</source>
        <translation>Lisa ala</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Move map to refine location.</source>
        <translation>Asukoha täpsustamiseks liigutage kaarti.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="105"/>
        <source>No Location Available.</source>
        <translation>Ühtegi asukohta pole saadaval.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw path.</source>
        <translation>Tee joonistamiseks puudutage kaarti.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw area.</source>
        <translation>Ala joonistamiseks puudutage kaarti.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="917"/>
        <source>%1 Meters</source>
        <translation>%1 meetrit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="918"/>
        <source>%1 Miles</source>
        <translation>%1 miili</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="919"/>
        <source>%1 Kilometers</source>
        <translation>%1 kilomeetrit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="920"/>
        <source>%1 Feet</source>
        <translation>%1 jalga</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="921"/>
        <source>%1 Feet (US)</source>
        <translation>%1 jalga (USA)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="922"/>
        <source>%1 Yards</source>
        <translation>%1 jardi</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="923"/>
        <source>%1 Nautical Miles</source>
        <translation>%1 meremiili</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="925"/>
        <source>%1 Sq Meters</source>
        <translation>%1 ruutmeetrit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="926"/>
        <source>%1 Acres</source>
        <translation>%1 aakrit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="927"/>
        <source>%1 Sq Miles</source>
        <translation>%1 ruutmiili</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="928"/>
        <source>%1 Sq Kilometers</source>
        <translation>%1 ruutkilomeetrit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="929"/>
        <source>%1 Hectares</source>
        <translation>%1 hektarit</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="930"/>
        <source>%1 Sq Yards</source>
        <translation>%1 ruutjardi</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="931"/>
        <source>%1 Sq Feet</source>
        <translation>%1 ruutjalga</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="932"/>
        <source>%1 Sq Feet (US)</source>
        <translation>%1 ruutjalga (USA)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="960"/>
        <source>Next</source>
        <translation>Järgmine</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid path. Continue?</source>
        <translation>Sobimatu teekond. Soovite jätkata?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid area. Continue?</source>
        <translation>Sobimatu ala. Soovite jätkata?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="972"/>
        <source>You can always save as draft and edit later.</source>
        <translation>Saate alati salvestada mustandina ja redigeerida hiljem.</translation>
    </message>
</context>
<context>
    <name>ResultsPage</name>
    <message>
        <location filename="../pages/ResultsPage.qml" line="73"/>
        <source>Thank You</source>
        <translation>Täname</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Done</source>
        <translation>Valmis</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Save</source>
        <translation>Salvesta</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="206"/>
        <source>Discard</source>
        <translation>Loobu</translation>
    </message>
</context>
<context>
    <name>SavedReportsPage</name>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="115"/>
        <source>Drafts</source>
        <translation>Mustandid</translation>
    </message>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="158"/>
        <source>You do not have any saved drafts right now.</source>
        <translation>Teil pole praegu ühtegi salvestatud mustandit.</translation>
    </message>
</context>
<context>
    <name>SelectIssuePage</name>
    <message>
        <location filename="../pages/SelectIssuePage.qml" line="117"/>
        <source>Submit</source>
        <translation>Esita</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="../controls/ServerDialog.qml" line="39"/>
        <source>Signing In</source>
        <translation>Sisselogimine</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="40"/>
        <source>Sign In</source>
        <translation>Logi sisse</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="125"/>
        <source>Username</source>
        <translation>Kasutajanimi</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="157"/>
        <source>Password</source>
        <translation>Parool</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="41"/>
        <source>Cancel</source>
        <translation>Tühista</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../controls/WebPage.qml" line="14"/>
        <source>Help</source>
        <translation>Abi</translation>
    </message>
</context>
</TS>
