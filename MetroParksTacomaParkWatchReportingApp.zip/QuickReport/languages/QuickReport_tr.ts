<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="60"/>
        <source>About</source>
        <translation>Yaklaşık</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="142"/>
        <source>Access and Use Constraints</source>
        <translation>Erişim ve Kullanım Kısıtlamaları</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="174"/>
        <source>Credits</source>
        <translation>Katkı Yapanlar</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="207"/>
        <source>About the App</source>
        <translation>Uygulama Hakkında</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="223"/>
        <source>This app was built using the new AppStudio for ArcGIS. Mapping API provided by Esri.</source>
        <translation>Bu uygulama, yeni AppStudio for ArcGIS kullanılarak oluşturulmuştur. Harita oluşturma API'si Esri tarafından sağlanmıştır.</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="238"/>
        <source>Version</source>
        <translation>Sürüm</translation>
    </message>
</context>
<context>
    <name>AddDetailsPage</name>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="117"/>
        <source>Add Details</source>
        <translation>Ayrıntı Ekle</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="172"/>
        <source>Submit</source>
        <translation>Gönder</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="184"/>
        <location filename="../pages/AddDetailsPage.qml" line="188"/>
        <source>Unable to submit.</source>
        <translation>Gönderilemiyor.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="185"/>
        <source>Add a valid map path.</source>
        <translation>Geçerli bir harita yolu ekleyin.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="189"/>
        <source>Add a valid map area.</source>
        <translation>Geçerli bir harita alanı ekleyin.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="156"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
</context>
<context>
    <name>AddPhotoPage</name>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="244"/>
        <source>Add Photo</source>
        <translation>Fotoğraf Ekle</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Add upto %1 photos.</source>
        <translation>%1 adede kadar fotoğraf ekleyin.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Larger images will be resized to %1 pixels.</source>
        <translation>Daha büyük görüntüler %1 piksel olarak yeniden boyutlandırılır.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="297"/>
        <source>Take Photo</source>
        <translation>Fotoğraf Çek</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="328"/>
        <location filename="../pages/AddPhotoPage.qml" line="564"/>
        <source>Select Photo</source>
        <translation>Fotoğraf Seç</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="413"/>
        <source>Next</source>
        <translation>Sonraki</translation>
    </message>
</context>
<context>
    <name>AndroidPictureChooser</name>
    <message>
        <location filename="../controls/AndroidPictureChooser.qml" line="103"/>
        <source>Sorry, no photos!</source>
        <translation>Üzgünüz, fotoğraf yok!</translation>
    </message>
</context>
<context>
    <name>CameraWindow</name>
    <message>
        <location filename="../pages/CameraWindow.qml" line="46"/>
        <source>Camera</source>
        <translation>Kamera</translation>
    </message>
</context>
<context>
    <name>ConfirmBox</name>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="34"/>
        <source>Are you sure you want to discard?</source>
        <translation>Silmek istediğinizden emin misiniz?</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="132"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="143"/>
        <source>Yes</source>
        <translation>Evet</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="154"/>
        <source>No</source>
        <translation>Hayır</translation>
    </message>
</context>
<context>
    <name>DisclamerPage</name>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="72"/>
        <source>Disclaimer</source>
        <translation>Feragatname</translation>
    </message>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="141"/>
        <source>Agree</source>
        <translation>Onaylıyorum</translation>
    </message>
</context>
<context>
    <name>EditControl</name>
    <message>
        <location filename="../controls/EditControl.qml" line="46"/>
        <source>Done</source>
        <translation>Bitti</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter some text</source>
        <translation>Metin girin</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Pick a Date</source>
        <translation>Tarih Seç</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter a number</source>
        <translation>Sayı girin</translation>
    </message>
</context>
<context>
    <name>ImageViewer</name>
    <message>
        <location filename="../controls/ImageViewer.qml" line="688"/>
        <source>NAME</source>
        <translation>AD</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="747"/>
        <source>LOCATION</source>
        <translation>KONUM</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="755"/>
        <source>Not Set</source>
        <translation>Ayarlanmadı</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="1052"/>
        <source>Are you sure you want to discard the changes?</source>
        <translation>Değişiklikleri silmek istediğinizden emin misiniz?</translation>
    </message>
</context>
<context>
    <name>LandingPage</name>
    <message>
        <location filename="../pages/LandingPage.qml" line="39"/>
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="221"/>
        <source>New</source>
        <translation>Yeni</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="241"/>
        <source>Drafts</source>
        <translation>Taslaklar</translation>
    </message>
</context>
<context>
    <name>PickTypePage</name>
    <message>
        <location filename="../pages/PickTypePage.qml" line="117"/>
        <source>Select Report Type</source>
        <translation>Rapor Türü Seç</translation>
    </message>
    <message>
        <location filename="../pages/PickTypePage.qml" line="173"/>
        <source>Next</source>
        <translation>Sonraki</translation>
    </message>
</context>
<context>
    <name>PictureChooser</name>
    <message>
        <location filename="../controls/PictureChooser.qml" line="29"/>
        <source>Pictures</source>
        <translation>Resimler</translation>
    </message>
    <message>
        <location filename="../controls/PictureChooser.qml" line="120"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
</context>
<context>
    <name>QuickReportApp</name>
    <message>
        <location filename="../QuickReportApp.qml" line="245"/>
        <source>Submitting the report</source>
        <translation>Rapor gönderiliyor</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="247"/>
        <source>Sorry there was an error!</source>
        <translation>Üzgünüz, bir hata oluştu!</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="248"/>
        <source>Photo size is </source>
        <translation>Fotoğraf boyutu: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="246"/>
        <source>Submitted successfully.</source>
        <translation>Başarıyla gönderildi.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="249"/>
        <source>Adding photo to draft: </source>
        <translation>Taslağa fotoğraf ekleniyor: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="250"/>
        <source>Photo added successfully: </source>
        <translation>Fotoğraf başarıyla eklendi: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="251"/>
        <source>Sorry could not add photo: </source>
        <translation>Üzgünüz, fotoğraf eklenemedi: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="253"/>
        <source>Please save as draft and submit later.</source>
        <translation>Taslak olarak kaydedin ve daha sonra gönderin.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="254"/>
        <source>Saved as draft.</source>
        <translation>Taslaklar olarak kaydedildi.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="578"/>
        <location filename="../QuickReportApp.qml" line="691"/>
        <source>Unable to initialize - Invalid service.</source>
        <translation>Başlatılamıyor - Geçersiz servis.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="579"/>
        <source>Please make sure the ArcGIS feature service supports</source>
        <translation>ArcGIS detay servisinin desteklediğinden emin olun</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="683"/>
        <source>Unable to initialize - Insufficient capability.</source>
        <translation>Başlatılamıyor - Yetersiz özellik.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="684"/>
        <source>Please make sure the ArcGIS feature service is editable.</source>
        <translation>ArcGIS detay servisinin düzenlenebilir olduğundan emin olun.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="692"/>
        <source>Please make sure you have configured a valid ArcGIS feature service url.</source>
        <translation>Geçerli bir ArcGIS detay servisi url’si yapılandırdığınızdan emin olun.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="698"/>
        <source>Unable to initialize - Network not available.</source>
        <translation>Başlatılamıyor - Ağ kullanılamıyor.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="699"/>
        <source>Turn off airplane mode or use wifi to access data.</source>
        <translation>Uçuş modunu kapatın veya veri erişimi için wifi kullanın.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="711"/>
        <source>Sorry, something went wrong.</source>
        <translation>Üzgünüz, hata oluştu.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="967"/>
        <source>Device OS</source>
        <translation>Cihaz İşletim Sistemi</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="968"/>
        <source>Device Locale</source>
        <translation>Cihaz Yerel Ayarları</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="969"/>
        <source>App Version</source>
        <translation>Uygulama Sürümü</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="970"/>
        <source>AppStudio Version</source>
        <translation>AppStudio Sürümü</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="973"/>
        <source>Feedback for</source>
        <translation>Şununla ilgili geri bildirim:</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="282"/>
        <source>Gallery</source>
        <translation>Galeri</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="252"/>
        <source>Click Done to continue.</source>
        <translation>Devam etmek için Bitti'ye tıklayın.</translation>
    </message>
</context>
<context>
    <name>RefineLocationPage</name>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="50"/>
        <source>Map not available in offline mode.</source>
        <translation>Harita çevrimdışı modda kullanılamıyor.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="51"/>
        <source>Using device GPS.</source>
        <translation>Cihaz GPS'si kullanılıyor.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="52"/>
        <source>Accuracy</source>
        <translation>Hassasiyet</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="53"/>
        <source>Latitude</source>
        <translation>Enlem</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="54"/>
        <source>Longitude</source>
        <translation>Boylam</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="55"/>
        <source>Select Bookmark</source>
        <translation>Yer İşareti Seç</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Location</source>
        <translation>Konum Ekle</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Path</source>
        <translation>Yol Ekle</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Area</source>
        <translation>Alan Ekle</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Move map to refine location.</source>
        <translation>Konumu iyileştirmek için haritayı taşıyın.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="105"/>
        <source>No Location Available.</source>
        <translation>Uygun Konum Yok.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw path.</source>
        <translation>Yol çizmek için haritaya dokunun.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw area.</source>
        <translation>Alan çizmek için haritaya dokunun.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="917"/>
        <source>%1 Meters</source>
        <translation>%1 Metre</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="918"/>
        <source>%1 Miles</source>
        <translation>%1 Mil</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="919"/>
        <source>%1 Kilometers</source>
        <translation>%1 Kilometre</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="920"/>
        <source>%1 Feet</source>
        <translation>%1 Feet</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="921"/>
        <source>%1 Feet (US)</source>
        <translation>%1 Feet (ABD)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="922"/>
        <source>%1 Yards</source>
        <translation>%1 Yarda</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="923"/>
        <source>%1 Nautical Miles</source>
        <translation>%1 Deniz Mili</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="925"/>
        <source>%1 Sq Meters</source>
        <translation>%1 Metre Kare</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="926"/>
        <source>%1 Acres</source>
        <translation>%1 Dönüm</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="927"/>
        <source>%1 Sq Miles</source>
        <translation>%1 Mil Kare</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="928"/>
        <source>%1 Sq Kilometers</source>
        <translation>%1 Kilometre Kare</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="929"/>
        <source>%1 Hectares</source>
        <translation>%1 Hektar</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="930"/>
        <source>%1 Sq Yards</source>
        <translation>%1 Yarda Kare</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="931"/>
        <source>%1 Sq Feet</source>
        <translation>%1 Feet Kare</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="932"/>
        <source>%1 Sq Feet (US)</source>
        <translation>%1 Feet Kare (ABD)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="960"/>
        <source>Next</source>
        <translation>Sonraki</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid path. Continue?</source>
        <translation>Geçersiz yol. Devam edilsin mi?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid area. Continue?</source>
        <translation>Geçersiz alan. Devam edilsin mi?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="972"/>
        <source>You can always save as draft and edit later.</source>
        <translation>Her zaman için taslak olarak kaydedebilir ve daha sonra düzenleyebilirsiniz.</translation>
    </message>
</context>
<context>
    <name>ResultsPage</name>
    <message>
        <location filename="../pages/ResultsPage.qml" line="73"/>
        <source>Thank You</source>
        <translation>Teşekkür Ederiz</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Done</source>
        <translation>Bitti</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="206"/>
        <source>Discard</source>
        <translation>At</translation>
    </message>
</context>
<context>
    <name>SavedReportsPage</name>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="115"/>
        <source>Drafts</source>
        <translation>Taslaklar</translation>
    </message>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="158"/>
        <source>You do not have any saved drafts right now.</source>
        <translation>Şu an için kaydedilmiş taslağınız yok.</translation>
    </message>
</context>
<context>
    <name>SelectIssuePage</name>
    <message>
        <location filename="../pages/SelectIssuePage.qml" line="117"/>
        <source>Submit</source>
        <translation>Gönder</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="../controls/ServerDialog.qml" line="39"/>
        <source>Signing In</source>
        <translation>Oturum açılıyor</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="40"/>
        <source>Sign In</source>
        <translation>Oturum Aç</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="125"/>
        <source>Username</source>
        <translation>Kullanıcı Adı</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="157"/>
        <source>Password</source>
        <translation>Parola</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="41"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../controls/WebPage.qml" line="14"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
</context>
</TS>
