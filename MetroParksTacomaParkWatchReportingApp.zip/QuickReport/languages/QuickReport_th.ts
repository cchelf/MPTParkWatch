<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="60"/>
        <source>About</source>
        <translation>เกี่ยวกับ</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="142"/>
        <source>Access and Use Constraints</source>
        <translation>การเข้าถึงและข้อจำกัด</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="174"/>
        <source>Credits</source>
        <translation>เครดิต</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="207"/>
        <source>About the App</source>
        <translation>เกี่ยวกับแอป</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="223"/>
        <source>This app was built using the new AppStudio for ArcGIS. Mapping API provided by Esri.</source>
        <translation>แอพนี้ถูกสร้างขึ้นโดยใช้AppStudio for ArcGIS ใหม่ ใช้ API การทำแผนที่จากEsri</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="238"/>
        <source>Version</source>
        <translation>เวอร์ชั่น</translation>
    </message>
</context>
<context>
    <name>AddDetailsPage</name>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="117"/>
        <source>Add Details</source>
        <translation>เพิ่มรายละเอียด</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="172"/>
        <source>Submit</source>
        <translation>ส่ง</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="184"/>
        <location filename="../pages/AddDetailsPage.qml" line="188"/>
        <source>Unable to submit.</source>
        <translation>ไม่สามารถส่ง</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="185"/>
        <source>Add a valid map path.</source>
        <translation>เพิ่มช่องแผนที่</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="189"/>
        <source>Add a valid map area.</source>
        <translation>เพิ่มพื้นที่บนแผนที่</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="156"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
</context>
<context>
    <name>AddPhotoPage</name>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="244"/>
        <source>Add Photo</source>
        <translation>เพิ่มรูปภาพ</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Add upto %1 photos.</source>
        <translation>เพิ่มจนถึง %1 รูป</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Larger images will be resized to %1 pixels.</source>
        <translation>ขนาดรูปใหญ่กว่าจะถูกลดขนาดเป็น %1 พิกเซล</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="297"/>
        <source>Take Photo</source>
        <translation>ถ่ายรูป</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="328"/>
        <location filename="../pages/AddPhotoPage.qml" line="564"/>
        <source>Select Photo</source>
        <translation>เลือกรูป</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="413"/>
        <source>Next</source>
        <translation>ถัดไป</translation>
    </message>
</context>
<context>
    <name>AndroidPictureChooser</name>
    <message>
        <location filename="../controls/AndroidPictureChooser.qml" line="103"/>
        <source>Sorry, no photos!</source>
        <translation>เสียใจ ไม่มีรูปภาพ</translation>
    </message>
</context>
<context>
    <name>CameraWindow</name>
    <message>
        <location filename="../pages/CameraWindow.qml" line="46"/>
        <source>Camera</source>
        <translation>กล้องถ่ายรูป</translation>
    </message>
</context>
<context>
    <name>ConfirmBox</name>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="34"/>
        <source>Are you sure you want to discard?</source>
        <translation>คุณแน่ใจว่าต้องการยกเลิก</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="132"/>
        <source>OK</source>
        <translation>ตกลง</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="143"/>
        <source>Yes</source>
        <translation>ใช่</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="154"/>
        <source>No</source>
        <translation>ไม่</translation>
    </message>
</context>
<context>
    <name>DisclamerPage</name>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="72"/>
        <source>Disclaimer</source>
        <translation>คำปฏิเสธ</translation>
    </message>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="141"/>
        <source>Agree</source>
        <translation>เห็นด้วย</translation>
    </message>
</context>
<context>
    <name>EditControl</name>
    <message>
        <location filename="../controls/EditControl.qml" line="46"/>
        <source>Done</source>
        <translation>เสร็จ</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter some text</source>
        <translation>ใส่ข้อความบางส่วน</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Pick a Date</source>
        <translation>เลือกวันที่</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter a number</source>
        <translation>ใส่ตัวเลข</translation>
    </message>
</context>
<context>
    <name>ImageViewer</name>
    <message>
        <location filename="../controls/ImageViewer.qml" line="688"/>
        <source>NAME</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="747"/>
        <source>LOCATION</source>
        <translation>สถานที่</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="755"/>
        <source>Not Set</source>
        <translation>ไม่ตั้งค่า</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="1052"/>
        <source>Are you sure you want to discard the changes?</source>
        <translation>คุณแน่ใจว่าต้องการยกเลิกหรือเปลี่ยนแปลง</translation>
    </message>
</context>
<context>
    <name>LandingPage</name>
    <message>
        <location filename="../pages/LandingPage.qml" line="39"/>
        <source>About</source>
        <translation>เกี่ยวกับ</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="221"/>
        <source>New</source>
        <translation>ใหม่</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="241"/>
        <source>Drafts</source>
        <translation>แบบร่าง</translation>
    </message>
</context>
<context>
    <name>PickTypePage</name>
    <message>
        <location filename="../pages/PickTypePage.qml" line="117"/>
        <source>Select Report Type</source>
        <translation>เลือกประเภทรายงาน</translation>
    </message>
    <message>
        <location filename="../pages/PickTypePage.qml" line="173"/>
        <source>Next</source>
        <translation>ถัดไป</translation>
    </message>
</context>
<context>
    <name>PictureChooser</name>
    <message>
        <location filename="../controls/PictureChooser.qml" line="29"/>
        <source>Pictures</source>
        <translation>รูปภาพ</translation>
    </message>
    <message>
        <location filename="../controls/PictureChooser.qml" line="120"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
</context>
<context>
    <name>QuickReportApp</name>
    <message>
        <location filename="../QuickReportApp.qml" line="245"/>
        <source>Submitting the report</source>
        <translation>กำลังส่งรายงาน</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="247"/>
        <source>Sorry there was an error!</source>
        <translation>ขออภัยมีข้อผิดพลาด!</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="248"/>
        <source>Photo size is </source>
        <translation>ขนาดของรูปถ่ายเป็น </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="246"/>
        <source>Submitted successfully.</source>
        <translation>การส่งสำเร็จเรียบร้อย</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="249"/>
        <source>Adding photo to draft: </source>
        <translation>เพิ่มรูปภาพไปยังดร๊าฟ </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="250"/>
        <source>Photo added successfully: </source>
        <translation>เพิ่มรูปสำเร็จ: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="251"/>
        <source>Sorry could not add photo: </source>
        <translation>ขอโทษไม่สามารถเพิ่มรูปได้ </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="253"/>
        <source>Please save as draft and submit later.</source>
        <translation>กรุณาบันทึกเป็นแบบร่างและเสนอต่อไป</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="254"/>
        <source>Saved as draft.</source>
        <translation>บันทึกเป็นดร๊าฟ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="578"/>
        <location filename="../QuickReportApp.qml" line="691"/>
        <source>Unable to initialize - Invalid service.</source>
        <translation>ไม่สามารถเริ่มต้น - บริการไม่ถูกต้อง</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="579"/>
        <source>Please make sure the ArcGIS feature service supports</source>
        <translation>โปรดตรวจสอบ ArcGIS คุณลักษณะบริการสนับสนุน</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="683"/>
        <source>Unable to initialize - Insufficient capability.</source>
        <translation>ไม่สามารถหาค่าเริ่มต้น - ความสามารถไม่เพียงพอ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="684"/>
        <source>Please make sure the ArcGIS feature service is editable.</source>
        <translation>โปรดตรวจสอบการให้บริการคุณลักษณะ ArcGIS สามารถแก้ไขได้</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="692"/>
        <source>Please make sure you have configured a valid ArcGIS feature service url.</source>
        <translation>กรุณาตรวจสอบให้แน่ใจว่าคุณได้กำหนดค่าที่ถูกต้องบน ArcGIS URL คุณลักษณะบริการ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="698"/>
        <source>Unable to initialize - Network not available.</source>
        <translation>ไม่สามารถหาค่าเริ่มต้นได้ - เครือข่ายไม่สามารถใช้ได้</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="699"/>
        <source>Turn off airplane mode or use wifi to access data.</source>
        <translation>ปิดโหมดใช้งานบนเครื่องบินหรือใช้ WiFi ในการเข้าถึงข้อมูล</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="711"/>
        <source>Sorry, something went wrong.</source>
        <translation>ขอโทษมีบางอย่างผิดพลาด</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="967"/>
        <source>Device OS</source>
        <translation>อุปกรณ์ OS</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="968"/>
        <source>Device Locale</source>
        <translation>อุปกรณ์สถานที่เกิดเหตุ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="969"/>
        <source>App Version</source>
        <translation>เวอร์ชั่นของแอพ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="970"/>
        <source>AppStudio Version</source>
        <translation>เวอร์ชั่น AppStudio</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="973"/>
        <source>Feedback for</source>
        <translation>แสดงความคิดเห็นสำหรับ</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="282"/>
        <source>Gallery</source>
        <translation>แกลเลอรี</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="252"/>
        <source>Click Done to continue.</source>
        <translation>คลิก เสร็จสิ้น เพื่อดำเนินการต่อไป</translation>
    </message>
</context>
<context>
    <name>RefineLocationPage</name>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="50"/>
        <source>Map not available in offline mode.</source>
        <translation>ไม่สามารถใช้แผนที่ขณะที่เป็นโหมดออฟไลน์</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="51"/>
        <source>Using device GPS.</source>
        <translation>ใช้อุปกรณ์ GPS</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="52"/>
        <source>Accuracy</source>
        <translation>ความถูกต้อง</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="53"/>
        <source>Latitude</source>
        <translation>ละติจูด</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="54"/>
        <source>Longitude</source>
        <translation>ลองจิจูด</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="55"/>
        <source>Select Bookmark</source>
        <translation>เลือกบุ๊คมาร์ค</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Location</source>
        <translation>เพิ่มสถานที่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Path</source>
        <translation>เพิ่มเส้นทาง</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Area</source>
        <translation>เพิ่มพื้นที่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Move map to refine location.</source>
        <translation>ย้ายแผนที่ไปยังตำแหน่งที่ว่างอยู่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="105"/>
        <source>No Location Available.</source>
        <translation>ไม่มีตำแหน่งอยู่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw path.</source>
        <translation>แตะบนแผนที่เพื่อวาดเส้นทาง</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw area.</source>
        <translation>แตะบนแผนที่เพื่อวาดพื้นที่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="917"/>
        <source>%1 Meters</source>
        <translation>%1 เมตร</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="918"/>
        <source>%1 Miles</source>
        <translation>%1ไมล์</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="919"/>
        <source>%1 Kilometers</source>
        <translation>%1 กิโลเมตร</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="920"/>
        <source>%1 Feet</source>
        <translation>%1 ฟุต</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="921"/>
        <source>%1 Feet (US)</source>
        <translation>%1 ฟุต (อเมริกา)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="922"/>
        <source>%1 Yards</source>
        <translation>%1 หลา</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="923"/>
        <source>%1 Nautical Miles</source>
        <translation>%1 ไมล์ทะเล</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="925"/>
        <source>%1 Sq Meters</source>
        <translation>%1 ตารางเมตร</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="926"/>
        <source>%1 Acres</source>
        <translation>%1 เอเคอร์</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="927"/>
        <source>%1 Sq Miles</source>
        <translation>%1 ตารางไมล์</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="928"/>
        <source>%1 Sq Kilometers</source>
        <translation>%1 ตารางกิโลเมตร</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="929"/>
        <source>%1 Hectares</source>
        <translation>%1 ตารางเฮคเตอร์</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="930"/>
        <source>%1 Sq Yards</source>
        <translation>%1 ตารางหลา</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="931"/>
        <source>%1 Sq Feet</source>
        <translation>%1 ตารางฟุต</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="932"/>
        <source>%1 Sq Feet (US)</source>
        <translation>%1 ตารางฟุต (อเมริกา)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="960"/>
        <source>Next</source>
        <translation>ถัดไป</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid path. Continue?</source>
        <translation>เส้นทางไม่ถูกต้อง ต้องการทำต่อหรือไม่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid area. Continue?</source>
        <translation>พื้นที่ไม่ถูกต้อง ต้องการทำต่อหรือไม่</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="972"/>
        <source>You can always save as draft and edit later.</source>
        <translation>คุณสามารถบันทึกเป็นดร๊าฟและแก้ไขในภายหลัง</translation>
    </message>
</context>
<context>
    <name>ResultsPage</name>
    <message>
        <location filename="../pages/ResultsPage.qml" line="73"/>
        <source>Thank You</source>
        <translation>ขอขอบคุณ</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Done</source>
        <translation>เสร็จ</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="206"/>
        <source>Discard</source>
        <translation>ละทิ้ง</translation>
    </message>
</context>
<context>
    <name>SavedReportsPage</name>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="115"/>
        <source>Drafts</source>
        <translation>แบบร่าง</translation>
    </message>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="158"/>
        <source>You do not have any saved drafts right now.</source>
        <translation>คุณไม่จำเป็นต้องบันทึกดร๊าฟขณะนี้</translation>
    </message>
</context>
<context>
    <name>SelectIssuePage</name>
    <message>
        <location filename="../pages/SelectIssuePage.qml" line="117"/>
        <source>Submit</source>
        <translation>ส่ง</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="../controls/ServerDialog.qml" line="39"/>
        <source>Signing In</source>
        <translation>กำลังเข้าระบบ</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="40"/>
        <source>Sign In</source>
        <translation>ลงชื่อเข้าใช้</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="125"/>
        <source>Username</source>
        <translation>ชื่อผู้ใช้</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="157"/>
        <source>Password</source>
        <translation>รหัสผ่าน</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="41"/>
        <source>Cancel</source>
        <translation>ยกเลิก</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../controls/WebPage.qml" line="14"/>
        <source>Help</source>
        <translation>ช่วยเหลือ</translation>
    </message>
</context>
</TS>
