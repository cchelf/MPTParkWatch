<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="60"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="142"/>
        <source>Access and Use Constraints</source>
        <translation>Restricciones de acceso y uso</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="174"/>
        <source>Credits</source>
        <translation>Créditos</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="207"/>
        <source>About the App</source>
        <translation>Acerca de la aplicación</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="223"/>
        <source>This app was built using the new AppStudio for ArcGIS. Mapping API provided by Esri.</source>
        <translation>Esta aplicación se ha creado usando el nuevo AppStudio for ArcGIS. API de representación cartográfica proporcionada por Esri</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="238"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
</context>
<context>
    <name>AddDetailsPage</name>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="117"/>
        <source>Add Details</source>
        <translation>Agregar detalles</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="172"/>
        <source>Submit</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="184"/>
        <location filename="../pages/AddDetailsPage.qml" line="188"/>
        <source>Unable to submit.</source>
        <translation>No se puede enviar.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="185"/>
        <source>Add a valid map path.</source>
        <translation>Agregue una ruta de mapa válida.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="189"/>
        <source>Add a valid map area.</source>
        <translation>Agregue un área de mapa válida.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="156"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
</context>
<context>
    <name>AddPhotoPage</name>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="244"/>
        <source>Add Photo</source>
        <translation>Agregar foto</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Add upto %1 photos.</source>
        <translation>Agregue %1 fotos como máximo.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Larger images will be resized to %1 pixels.</source>
        <translation>El tamaño de las imágenes más grandes se ajustará a %1 píxeles.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="297"/>
        <source>Take Photo</source>
        <translation>Tomar foto</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="328"/>
        <location filename="../pages/AddPhotoPage.qml" line="564"/>
        <source>Select Photo</source>
        <translation>Seleccionar foto</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="413"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
</context>
<context>
    <name>AndroidPictureChooser</name>
    <message>
        <location filename="../controls/AndroidPictureChooser.qml" line="103"/>
        <source>Sorry, no photos!</source>
        <translation>Lo lamentamos, no hay fotos.</translation>
    </message>
</context>
<context>
    <name>CameraWindow</name>
    <message>
        <location filename="../pages/CameraWindow.qml" line="46"/>
        <source>Camera</source>
        <translation>Cámara</translation>
    </message>
</context>
<context>
    <name>ConfirmBox</name>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="34"/>
        <source>Are you sure you want to discard?</source>
        <translation>¿Está seguro de que desea descartar?</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="132"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="143"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="154"/>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>DisclamerPage</name>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="72"/>
        <source>Disclaimer</source>
        <translation>Renuncia de responsabilidad</translation>
    </message>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="141"/>
        <source>Agree</source>
        <translation>Acepto</translation>
    </message>
</context>
<context>
    <name>EditControl</name>
    <message>
        <location filename="../controls/EditControl.qml" line="46"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter some text</source>
        <translation>Introduzca texto</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Pick a Date</source>
        <translation>Seleccione una fecha</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter a number</source>
        <translation>Introduzca un número</translation>
    </message>
</context>
<context>
    <name>ImageViewer</name>
    <message>
        <location filename="../controls/ImageViewer.qml" line="688"/>
        <source>NAME</source>
        <translation>NOMBRE</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="747"/>
        <source>LOCATION</source>
        <translation>UBICACIÓN</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="755"/>
        <source>Not Set</source>
        <translation>No definido</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="1052"/>
        <source>Are you sure you want to discard the changes?</source>
        <translation>¿Está seguro de que desea descartar los cambios?</translation>
    </message>
</context>
<context>
    <name>LandingPage</name>
    <message>
        <location filename="../pages/LandingPage.qml" line="39"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="221"/>
        <source>New</source>
        <translation>Nuevo</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="241"/>
        <source>Drafts</source>
        <translation>Borradores</translation>
    </message>
</context>
<context>
    <name>PickTypePage</name>
    <message>
        <location filename="../pages/PickTypePage.qml" line="117"/>
        <source>Select Report Type</source>
        <translation>Seleccionar tipo de informe</translation>
    </message>
    <message>
        <location filename="../pages/PickTypePage.qml" line="173"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
</context>
<context>
    <name>PictureChooser</name>
    <message>
        <location filename="../controls/PictureChooser.qml" line="29"/>
        <source>Pictures</source>
        <translation>Imágenes</translation>
    </message>
    <message>
        <location filename="../controls/PictureChooser.qml" line="120"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
</context>
<context>
    <name>QuickReportApp</name>
    <message>
        <location filename="../QuickReportApp.qml" line="245"/>
        <source>Submitting the report</source>
        <translation>Enviando el informe</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="247"/>
        <source>Sorry there was an error!</source>
        <translation>Se produjo un error.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="248"/>
        <source>Photo size is </source>
        <translation>El tamaño de la foto es </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="246"/>
        <source>Submitted successfully.</source>
        <translation>Se ha enviado correctamente.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="249"/>
        <source>Adding photo to draft: </source>
        <translation>Agregando foto al borrador: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="250"/>
        <source>Photo added successfully: </source>
        <translation>La foto se agregó correctamente: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="251"/>
        <source>Sorry could not add photo: </source>
        <translation>No se pudo agregar la foto: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="253"/>
        <source>Please save as draft and submit later.</source>
        <translation>Guarde como borrador y envíe más tarde.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="254"/>
        <source>Saved as draft.</source>
        <translation>Guardado como borrador.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="578"/>
        <location filename="../QuickReportApp.qml" line="691"/>
        <source>Unable to initialize - Invalid service.</source>
        <translation>No se puede inicializar: servicio no válido.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="579"/>
        <source>Please make sure the ArcGIS feature service supports</source>
        <translation>Asegúrese de que el servicio de entidades de ArcGIS es compatible con</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="683"/>
        <source>Unable to initialize - Insufficient capability.</source>
        <translation>No se puede inicializar: capacidad insuficiente.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="684"/>
        <source>Please make sure the ArcGIS feature service is editable.</source>
        <translation>Asegúrese de que el servicio de entidades de ArcGIS es editable.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="692"/>
        <source>Please make sure you have configured a valid ArcGIS feature service url.</source>
        <translation>Asegúrese de que ha configurado una dirección URL de servicio de entidades de ArcGIS válida.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="698"/>
        <source>Unable to initialize - Network not available.</source>
        <translation>No se puede inicializar: la red no está disponible.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="699"/>
        <source>Turn off airplane mode or use wifi to access data.</source>
        <translation>Desactive el modo avión o utilice una conexión wifi para acceder a los datos.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="711"/>
        <source>Sorry, something went wrong.</source>
        <translation>Se ha producido un error.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="967"/>
        <source>Device OS</source>
        <translation>SO de dispositivo</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="968"/>
        <source>Device Locale</source>
        <translation>Configuración regional de dispositivo</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="969"/>
        <source>App Version</source>
        <translation>Versión de la aplicación</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="970"/>
        <source>AppStudio Version</source>
        <translation>Versión de AppStudio</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="973"/>
        <source>Feedback for</source>
        <translation>Comentarios para</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="282"/>
        <source>Gallery</source>
        <translation>Galería</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="252"/>
        <source>Click Done to continue.</source>
        <translation>Haga clic en Hecho para continuar.</translation>
    </message>
</context>
<context>
    <name>RefineLocationPage</name>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="50"/>
        <source>Map not available in offline mode.</source>
        <translation>Mapa no disponible en modo sin conexión.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="51"/>
        <source>Using device GPS.</source>
        <translation>Utilizando GPS de dispositivo.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="52"/>
        <source>Accuracy</source>
        <translation>Precisión</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="53"/>
        <source>Latitude</source>
        <translation>Latitud</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="54"/>
        <source>Longitude</source>
        <translation>Longitud</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="55"/>
        <source>Select Bookmark</source>
        <translation>Seleccionar marcador</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Location</source>
        <translation>Agregar ubicación</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Path</source>
        <translation>Agregar ruta</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Area</source>
        <translation>Agregar área</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Move map to refine location.</source>
        <translation>Mueva el mapa para delimitar la ubicación.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="105"/>
        <source>No Location Available.</source>
        <translation>No hay ninguna ubicación disponible.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw path.</source>
        <translation>Toque en el mapa para dibujar la ruta.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw area.</source>
        <translation>Toque en el mapa para dibujar el área.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="917"/>
        <source>%1 Meters</source>
        <translation>%1 metros</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="918"/>
        <source>%1 Miles</source>
        <translation>%1 millas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="919"/>
        <source>%1 Kilometers</source>
        <translation>%1 kilómetros</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="920"/>
        <source>%1 Feet</source>
        <translation>%1 pies</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="921"/>
        <source>%1 Feet (US)</source>
        <translation>%1 pies (EE. UU.)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="922"/>
        <source>%1 Yards</source>
        <translation>%1 yardas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="923"/>
        <source>%1 Nautical Miles</source>
        <translation>%1 millas náuticas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="925"/>
        <source>%1 Sq Meters</source>
        <translation>%1 metros cuadrados</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="926"/>
        <source>%1 Acres</source>
        <translation>%1 acres</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="927"/>
        <source>%1 Sq Miles</source>
        <translation>%1 millas cuadradas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="928"/>
        <source>%1 Sq Kilometers</source>
        <translation>%1 kilómetros cuadrados</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="929"/>
        <source>%1 Hectares</source>
        <translation>%1 hectáreas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="930"/>
        <source>%1 Sq Yards</source>
        <translation>%1 yardas cuadradas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="931"/>
        <source>%1 Sq Feet</source>
        <translation>%1 pies cuadrados</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="932"/>
        <source>%1 Sq Feet (US)</source>
        <translation>%1 pies cuadrados (EE. UU.)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="960"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid path. Continue?</source>
        <translation>Ruta no válida. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid area. Continue?</source>
        <translation>Área no válida. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="972"/>
        <source>You can always save as draft and edit later.</source>
        <translation>Siempre puede guardar como borrador y editar más tarde.</translation>
    </message>
</context>
<context>
    <name>ResultsPage</name>
    <message>
        <location filename="../pages/ResultsPage.qml" line="73"/>
        <source>Thank You</source>
        <translation>Gracias</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="206"/>
        <source>Discard</source>
        <translation>Descartar</translation>
    </message>
</context>
<context>
    <name>SavedReportsPage</name>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="115"/>
        <source>Drafts</source>
        <translation>Borradores</translation>
    </message>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="158"/>
        <source>You do not have any saved drafts right now.</source>
        <translation>No tiene ningún borrador guardado en este momento.</translation>
    </message>
</context>
<context>
    <name>SelectIssuePage</name>
    <message>
        <location filename="../pages/SelectIssuePage.qml" line="117"/>
        <source>Submit</source>
        <translation>Enviar</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="../controls/ServerDialog.qml" line="39"/>
        <source>Signing In</source>
        <translation>Iniciando sesión</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="40"/>
        <source>Sign In</source>
        <translation>Iniciar sesión</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="125"/>
        <source>Username</source>
        <translation>Nombre de usuario</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="157"/>
        <source>Password</source>
        <translation>Contraseña</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="41"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../controls/WebPage.qml" line="14"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
</context>
</TS>
