<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutPage</name>
    <message>
        <location filename="../pages/AboutPage.qml" line="60"/>
        <source>About</source>
        <translation>Par</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="142"/>
        <source>Access and Use Constraints</source>
        <translation>Piekļuves un izmantošanas ierobežojumi</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="174"/>
        <source>Credits</source>
        <translation>Kredīti</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="207"/>
        <source>About the App</source>
        <translation>Par lietotni</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="223"/>
        <source>This app was built using the new AppStudio for ArcGIS. Mapping API provided by Esri.</source>
        <translation>Šī lietotne ir izveidota, izmantojot jauno pakalpojumu AppStudio for ArcGIS. Kartēšanas API nodrošina Esri.</translation>
    </message>
    <message>
        <location filename="../pages/AboutPage.qml" line="238"/>
        <source>Version</source>
        <translation>Versija</translation>
    </message>
</context>
<context>
    <name>AddDetailsPage</name>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="117"/>
        <source>Add Details</source>
        <translation>Pievienot detalizētu informāciju</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="172"/>
        <source>Submit</source>
        <translation>Iesniegt</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="184"/>
        <location filename="../pages/AddDetailsPage.qml" line="188"/>
        <source>Unable to submit.</source>
        <translation>Nevar iesniegt.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="185"/>
        <source>Add a valid map path.</source>
        <translation>Pievienojiet derīgu kartes ceļu.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="189"/>
        <source>Add a valid map area.</source>
        <translation>Pievienojiet derīgu kartes teritoriju.</translation>
    </message>
    <message>
        <location filename="../pages/AddDetailsPage.qml" line="156"/>
        <source>Save</source>
        <translation>Saglabāt</translation>
    </message>
</context>
<context>
    <name>AddPhotoPage</name>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="244"/>
        <source>Add Photo</source>
        <translation>Foto pievienošana</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Add upto %1 photos.</source>
        <translation>Pievienojiet līdz pat šādam skaitam fotoattēlu: %1.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="258"/>
        <source>Larger images will be resized to %1 pixels.</source>
        <translation>Lielāku attēlu izmērs tiks mainīts uz %1 pikseļiem.</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="297"/>
        <source>Take Photo</source>
        <translation>Uzņemt fotoattēlu</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="328"/>
        <location filename="../pages/AddPhotoPage.qml" line="564"/>
        <source>Select Photo</source>
        <translation>Izvēlēties fotoattēlu</translation>
    </message>
    <message>
        <location filename="../pages/AddPhotoPage.qml" line="413"/>
        <source>Next</source>
        <translation>Nākamais</translation>
    </message>
</context>
<context>
    <name>AndroidPictureChooser</name>
    <message>
        <location filename="../controls/AndroidPictureChooser.qml" line="103"/>
        <source>Sorry, no photos!</source>
        <translation>Diemžēl fotoattēlu nav!</translation>
    </message>
</context>
<context>
    <name>CameraWindow</name>
    <message>
        <location filename="../pages/CameraWindow.qml" line="46"/>
        <source>Camera</source>
        <translation>Kamera</translation>
    </message>
</context>
<context>
    <name>ConfirmBox</name>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="34"/>
        <source>Are you sure you want to discard?</source>
        <translation>Vai tiešām vēlaties atmest?</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="132"/>
        <source>OK</source>
        <translation>Labi</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="143"/>
        <source>Yes</source>
        <translation>Jā</translation>
    </message>
    <message>
        <location filename="../controls/ConfirmBox.qml" line="154"/>
        <source>No</source>
        <translation>Nē</translation>
    </message>
</context>
<context>
    <name>DisclamerPage</name>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="72"/>
        <source>Disclaimer</source>
        <translation>Atsaukšana</translation>
    </message>
    <message>
        <location filename="../pages/DisclamerPage.qml" line="141"/>
        <source>Agree</source>
        <translation>Piekrītu</translation>
    </message>
</context>
<context>
    <name>EditControl</name>
    <message>
        <location filename="../controls/EditControl.qml" line="46"/>
        <source>Done</source>
        <translation>Gatavs</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter some text</source>
        <translation>Ievadiet kādu tekstu</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Pick a Date</source>
        <translation>Izvēlieties datumu</translation>
    </message>
    <message>
        <location filename="../controls/EditControl.qml" line="152"/>
        <source>Enter a number</source>
        <translation>Ievadiet skaitli</translation>
    </message>
</context>
<context>
    <name>ImageViewer</name>
    <message>
        <location filename="../controls/ImageViewer.qml" line="688"/>
        <source>NAME</source>
        <translation>NOSAUKUMS</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="747"/>
        <source>LOCATION</source>
        <translation>IZVIETOJUMS</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="755"/>
        <source>Not Set</source>
        <translation>Nav iestatīts</translation>
    </message>
    <message>
        <location filename="../controls/ImageViewer.qml" line="1052"/>
        <source>Are you sure you want to discard the changes?</source>
        <translation>Vai tiešām vēlaties atmest izmaiņas?</translation>
    </message>
</context>
<context>
    <name>LandingPage</name>
    <message>
        <location filename="../pages/LandingPage.qml" line="39"/>
        <source>About</source>
        <translation>Par</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="221"/>
        <source>New</source>
        <translation>Jauns</translation>
    </message>
    <message>
        <location filename="../pages/LandingPage.qml" line="241"/>
        <source>Drafts</source>
        <translation>Skices</translation>
    </message>
</context>
<context>
    <name>PickTypePage</name>
    <message>
        <location filename="../pages/PickTypePage.qml" line="117"/>
        <source>Select Report Type</source>
        <translation>Izvēlēties pārskata tipu</translation>
    </message>
    <message>
        <location filename="../pages/PickTypePage.qml" line="173"/>
        <source>Next</source>
        <translation>Nākamais</translation>
    </message>
</context>
<context>
    <name>PictureChooser</name>
    <message>
        <location filename="../controls/PictureChooser.qml" line="29"/>
        <source>Pictures</source>
        <translation>Attēli</translation>
    </message>
    <message>
        <location filename="../controls/PictureChooser.qml" line="120"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
</context>
<context>
    <name>QuickReportApp</name>
    <message>
        <location filename="../QuickReportApp.qml" line="245"/>
        <source>Submitting the report</source>
        <translation>Pārskata iesniegšana</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="247"/>
        <source>Sorry there was an error!</source>
        <translation>Diemžēl radās kļūda!</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="248"/>
        <source>Photo size is </source>
        <translation>Fotoattēla lielums ir </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="246"/>
        <source>Submitted successfully.</source>
        <translation>Veiksmīgi iesniegts.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="249"/>
        <source>Adding photo to draft: </source>
        <translation>Fotoattēla pievienošana skicei: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="250"/>
        <source>Photo added successfully: </source>
        <translation>Fotoattēls pievienots sekmīgi: </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="251"/>
        <source>Sorry could not add photo: </source>
        <translation>Diemžēl nevarēja pievienot fotoattēlu! </translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="253"/>
        <source>Please save as draft and submit later.</source>
        <translation>Lūdzu, saglabājiet kā melnrakstu un iesniedziet vēlāk.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="254"/>
        <source>Saved as draft.</source>
        <translation>Saglabāta kā skice.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="578"/>
        <location filename="../QuickReportApp.qml" line="691"/>
        <source>Unable to initialize - Invalid service.</source>
        <translation>Nevar inicializēt — nederīgs pakalpojums.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="579"/>
        <source>Please make sure the ArcGIS feature service supports</source>
        <translation>Pārliecinieties, vai ArcGIS elementu pakalpojums atbalsta</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="683"/>
        <source>Unable to initialize - Insufficient capability.</source>
        <translation>Nevar inicializēt — nepietiekama ietilpība.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="684"/>
        <source>Please make sure the ArcGIS feature service is editable.</source>
        <translation>Pārliecinieties, vai ArcGIS elementu pakalpojums ir labojams.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="692"/>
        <source>Please make sure you have configured a valid ArcGIS feature service url.</source>
        <translation>Pārliecinieties, vai esat konfigurējis derīgu ArcGIS elementu pakalpojuma URL.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="698"/>
        <source>Unable to initialize - Network not available.</source>
        <translation>Nevar inicializēt — tīkls nav pieejams.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="699"/>
        <source>Turn off airplane mode or use wifi to access data.</source>
        <translation>Izslēdziet lidmašīnas režīmu vai izmantojiet Wi-Fi, lai piekļūtu datiem.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="711"/>
        <source>Sorry, something went wrong.</source>
        <translation>Diemžēl radās problēma.</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="967"/>
        <source>Device OS</source>
        <translation>Ierīces OS</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="968"/>
        <source>Device Locale</source>
        <translation>Ierīces lokalizācija</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="969"/>
        <source>App Version</source>
        <translation>Lietotnes versija</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="970"/>
        <source>AppStudio Version</source>
        <translation>AppStudio versija</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="973"/>
        <source>Feedback for</source>
        <translation>Atsauksmes par</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="282"/>
        <source>Gallery</source>
        <translation>Galerija</translation>
    </message>
    <message>
        <location filename="../QuickReportApp.qml" line="252"/>
        <source>Click Done to continue.</source>
        <translation>Noklikšķiniet uz Pabeigts, lai turpinātu</translation>
    </message>
</context>
<context>
    <name>RefineLocationPage</name>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="50"/>
        <source>Map not available in offline mode.</source>
        <translation>Karte nav pieejama bezsaistes režīmā.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="51"/>
        <source>Using device GPS.</source>
        <translation>Ierīces GPS izmantošana.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="52"/>
        <source>Accuracy</source>
        <translation>Precizitāte</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="53"/>
        <source>Latitude</source>
        <translation>Platums</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="54"/>
        <source>Longitude</source>
        <translation>Garums</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="55"/>
        <source>Select Bookmark</source>
        <translation>Izvēlēties grāmatzīmi</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Location</source>
        <translation>Pievienot izvietojumu</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Path</source>
        <translation>Pievienot ceļu</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="222"/>
        <source>Add Area</source>
        <translation>Pievienot teritoriju</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Move map to refine location.</source>
        <translation>Pārvietot karti, lai uzlabotu izvietojumu.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="105"/>
        <source>No Location Available.</source>
        <translation>Nav pieejams neviens izvietojums.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw path.</source>
        <translation>Lai zīmētu ceļu, pieskarieties kartei.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="243"/>
        <source>Tap on the map to draw area.</source>
        <translation>Lai zīmētu teritoriju, pieskarieties kartei.</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="917"/>
        <source>%1 Meters</source>
        <translation>%1 metri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="918"/>
        <source>%1 Miles</source>
        <translation>%1 jūdzes</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="919"/>
        <source>%1 Kilometers</source>
        <translation>%1 kilometri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="920"/>
        <source>%1 Feet</source>
        <translation>%1 pēdas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="921"/>
        <source>%1 Feet (US)</source>
        <translation>%1 pēdas (Amerikas)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="922"/>
        <source>%1 Yards</source>
        <translation>%1 jardi</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="923"/>
        <source>%1 Nautical Miles</source>
        <translation>%1 jūras jūdzes</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="925"/>
        <source>%1 Sq Meters</source>
        <translation>%1 kvadrātmetri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="926"/>
        <source>%1 Acres</source>
        <translation>%1 akri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="927"/>
        <source>%1 Sq Miles</source>
        <translation>%1 kvadrātjūdzes</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="928"/>
        <source>%1 Sq Kilometers</source>
        <translation>%1 kvadrātkilometri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="929"/>
        <source>%1 Hectares</source>
        <translation>%1 hektāri</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="930"/>
        <source>%1 Sq Yards</source>
        <translation>%1 kvadrātjardi</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="931"/>
        <source>%1 Sq Feet</source>
        <translation>%1 kvadrātpēdas</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="932"/>
        <source>%1 Sq Feet (US)</source>
        <translation>%1 kvadrātpēdas (Amerikas)</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="960"/>
        <source>Next</source>
        <translation>Nākamais</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid path. Continue?</source>
        <translation>Nederīgs ceļš. Vai turpināt?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="971"/>
        <source>Invalid area. Continue?</source>
        <translation>Nederīga teritorija. Vai turpināt?</translation>
    </message>
    <message>
        <location filename="../pages/RefineLocationPage.qml" line="972"/>
        <source>You can always save as draft and edit later.</source>
        <translation>Vienmēr varat saglabāt kā skici un vēlāk labot.</translation>
    </message>
</context>
<context>
    <name>ResultsPage</name>
    <message>
        <location filename="../pages/ResultsPage.qml" line="73"/>
        <source>Thank You</source>
        <translation>Paldies</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Done</source>
        <translation>Pabeigts</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="179"/>
        <source>Save</source>
        <translation>Saglabāt</translation>
    </message>
    <message>
        <location filename="../pages/ResultsPage.qml" line="206"/>
        <source>Discard</source>
        <translation>Atmest</translation>
    </message>
</context>
<context>
    <name>SavedReportsPage</name>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="115"/>
        <source>Drafts</source>
        <translation>Melnraksti</translation>
    </message>
    <message>
        <location filename="../pages/SavedReportsPage.qml" line="158"/>
        <source>You do not have any saved drafts right now.</source>
        <translation>Jums pašlaik nav neviena saglabāta melnraksta.</translation>
    </message>
</context>
<context>
    <name>SelectIssuePage</name>
    <message>
        <location filename="../pages/SelectIssuePage.qml" line="117"/>
        <source>Submit</source>
        <translation>Iesniegt</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="../controls/ServerDialog.qml" line="39"/>
        <source>Signing In</source>
        <translation>Pierakstīšanās</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="40"/>
        <source>Sign In</source>
        <translation>Pierakstīties</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="125"/>
        <source>Username</source>
        <translation>Lietotājvārds</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="157"/>
        <source>Password</source>
        <translation>Parole</translation>
    </message>
    <message>
        <location filename="../controls/ServerDialog.qml" line="41"/>
        <source>Cancel</source>
        <translation>Atcelt</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../controls/WebPage.qml" line="14"/>
        <source>Help</source>
        <translation>Palīdzība</translation>
    </message>
</context>
</TS>
