# QuickReport

##Warning when pushing this content to AGOL
When copying the contents of this repo to AGOL be sure to NOT include the follow files and folders:
 - .git
 - .gitignore
 - .info.json
 - README.md
 
The presense of these git files will cause any app built upon this template, to NOT BUILD EXECUTABLES.
